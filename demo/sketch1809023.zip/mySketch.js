function setup() {
	createCanvas(windowWidth, windowHeight);
	background(100);
	circle(mouseX, mouseY, 20);
} //end of setup function

function draw() {
	
}//end of draw