function setup() {
	createCanvas(500, 500);
	rectMode(CENTER); //changes rectangle origin 
} //end of setup function

function draw() {
	background(	255, 103, 31); //dd orange

	
	
	fill(255); //white
	strokeWeight(5);//thickness of border
	//noFill();//turns off fill
	rect(250, 250,200, 200, 10);
	
			
	noStroke(); //turn off stroke
	fill(218, 24, 132); //dd magenta
	circle(250, 250, 100);

}//end of draw








