//global

function setup() {
	createCanvas(500,500);
	//background(239,21,204);//lightblue 
	background(30);
	rectMode(CENTER);
}//close setup

function draw() {
	
	//fill(60,195,154);//pink
	fill(230, 0, 18);//red
rect(250,250,250,250)//retangle
	fill(0, 195, 227);//blue
	circle(250,250,80);//circle
	/*
	if(mouseIsPressed == true){
	circle(mouseX, mouseY, 20);
	}//close if
	*/
}//close draw