function setup() {
	createCanvas(500, 500);
rectMode(CENTER); //changes rectangle origin

} //end of setup function

function draw() {
	background(182, 116, 2) //orange
	fill(218, 24, 132); // dd meganta
	rect(250, 250, 100, 100);
	fill(36, 182, 2)
	circle(250, 250, 50);


} //end of draw function




